import argparse
import sys
import os
import numpy as np
from tqdm import tqdm
import random
import librosa
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import AutoFeatureExtractor
from sklearn.metrics import roc_auc_score
from collections import defaultdict, Counter
from models import Wav2Vec2BERT
from data_utils import get_combined_loader, get_test_loader, pad, seed_worker, AudioDataset, compute_det_curve, compute_eer, run_validation
from datetime import datetime

device = "cuda" if torch.cuda.is_available() else "cpu"

def main(args):
    # Seed for reproducibility
    seed = args.seed
    np.random.seed(seed)
    torch.manual_seed(seed)
    random.seed(seed)

    # Output directories
    output_dir = args.output_dir
    eval_ckpt = os.path.join(output_dir, "eval")

    # Model parameters
    pretrained_model_name = args.pretrained_model_name
    if pretrained_model_name == 'wave2vec2bert':
        model_name = "facebook/w2v-bert-2.0"
        model = Wav2Vec2BERT(model_name)
        sampling_rate = 16000
    else:
        raise ValueError(f"Model {pretrained_model_name} not supported")
        sys.exit(0)

    model = model.to(device)
    feature_extractor = AutoFeatureExtractor.from_pretrained(model_name)

    if args.eval:
        in_the_wild_loader = get_in_the_wild_loader(args.data_path, seed=seed, batch_size=args.batch_size)
        print(f"Start evaluating In-the-wild using {device}")
        run_validation(model, feature_extractor, in_the_wild_loader, sr=sampling_rate)
        print('Evaluation finished')
        sys.exit(0)

    if args.train:
        print(f"Start Finetuning using {device}")
        torch.cuda.empty_cache()
        database_path_list = args.data_path
        print(database_path_list)
        trn_loader, val_loader, test_loader = get_combined_loader(database_path_list, seed, args.batch_size)
        optim = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        model.train()
        for epoch in range(args.epochs):
            print(f'{output_dir}/{args.dataset_name}_{pretrained_model_name}_epoch_{epoch}_{args.lr}_{datetime.now()}.pth')
            outputs_list, labels_list, train_loss, auroc_list, acc_list, err_list = [], [], [], [], [], []
            num_total, steps = 0, 0

            for batch_x, batch_y, name in tqdm(trn_loader, desc="Finetuning"):
                batch_size = batch_x.size(0)
                num_total += batch_size
                steps += 1

                batch_x = batch_x.numpy()
                inputs = feature_extractor(batch_x, sampling_rate=sampling_rate, return_attention_mask=True, padding_value=0, return_tensors="pt").to(device)
                batch_y = batch_y.to(device)
                inputs['labels'] = batch_y

                outputs = model(**inputs)
                train_loss.append(outputs.loss.item())

                batch_probs = outputs.logits.softmax(dim=-1)
                outputs_list.extend(batch_probs[:, 1].cpu().tolist())
                labels_list.extend(batch_y.detach().cpu().numpy().tolist())

                optim.zero_grad()
                outputs.loss.backward()
                optim.step()

                if steps % args.eval_steps == 0:
                    eval_acc, eval_auroc, eval_eer = run_validation(model, feature_extractor, val_loader, sr=sampling_rate)
                    auroc_list.append(eval_auroc)
                    acc_list.append(eval_acc)
                    err_list.append(eval_eer[0])
                    model.train()

            auroc = roc_auc_score(labels_list, outputs_list)
            eer = compute_eer(np.array(labels_list), np.array(outputs_list))
            print(f'Training epoch: {epoch} \t AUROC: {auroc} \t EER: {eer}')
            os.makedirs(output_dir, exist_ok=True)
            torch.save(model.state_dict(), f'{output_dir}/{args.dataset_name}_{pretrained_model_name}_epoch_{epoch}_{args.lr}_{datetime.now()}.pth')
            torch.cuda.empty_cache()
        print(f'Finetuning with combined {args.dataset_name} finished')
        sys.exit(0)

    if args.test:
        for database_path_list in [args.data_path]:
            dataset_name = database_path_list
            test_loader = get_test_loader(database_path_list, seed, args.batch_size)
            checkpoint_list = [args.checkpoint]
            for checkpoint_name in checkpoint_list:
                print(f"Start testing with:{dataset_name}_checkpoint:{checkpoint_name} {device}")
                model_path = os.path.join(output_dir, checkpoint_name)
                model.load_state_dict(torch.load(model_path, weights_only=True))
                model.eval()
                run_validation(model, feature_extractor, test_loader, sr=sampling_rate)
                print('Evaluation finished')
        sys.exit(0)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train, evaluate, and test a Wav2Vec2BERT model.")
    parser.add_argument("--seed", type=int, default=1234, help="Random seed for reproducibility")
    parser.add_argument("--output_dir", type=str, default="./ckpt", help="Directory to save checkpoints and outputs")
    parser.add_argument("--pretrained_model_name", type=str, default="wave2vec2bert", help="Name of the pretrained model")
    parser.add_argument("--data_path", type=str, nargs='+', required=True, help="List of paths to the training data")
    parser.add_argument("--epochs", type=int, default=1, help="Number of training epochs")
    parser.add_argument("--batch_size", type=int, default=32, help="Batch size for training and evaluation")
    parser.add_argument("--lr", type=float, default=1e-5, help="Learning rate for the optimizer")
    parser.add_argument("--weight_decay", type=float, default=5e-5, help="Weight decay for the optimizer")
    parser.add_argument("--eval_steps", type=int, default=1000, help="Number of steps between evaluations")
    parser.add_argument("--dataset_name", type=str, default="dataset", help="Name of the dataset")
    parser.add_argument("--checkpoint", type=str, default="", help="Checkpoint file for testing")
    parser.add_argument("--train", type=bool, default=False, help="Flag to run training")
    parser.add_argument("--eval", type=bool, default=False, help="Flag to run training")
    parser.add_argument("--test", type=bool, default=False, help="Flag to run training")

    args = parser.parse_args()
    main(args)

    """
    python train.py --data_path "../data/for-norm/" --train True --batch_size 64

    python train.py --data_path "../data/in_the_wild/" --test True --batch_size 128 --checkpoint "dataset_wave2vec2bert_epoch_0_1e-05_2025-03-26 14:12:03.288761.pth"
    
    """